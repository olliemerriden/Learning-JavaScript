
const numbers = [1, -1, 2, 3];

// return on positive
const filtered = numbers.filter(value => value >= 0); // value where the value is greater than or = to 0

console.log(filtered); // returns 1,2,3

