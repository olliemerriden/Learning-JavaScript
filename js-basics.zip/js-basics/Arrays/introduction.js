// learn operations that you can perform on arrays

// adding new elements
// finding elements
// removing elements
// splitting arrays
// combining arrays

