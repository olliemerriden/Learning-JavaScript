

function isLandscape (width, height) {
   return (width > height);
}

console.log(isLandscape(700, 400));