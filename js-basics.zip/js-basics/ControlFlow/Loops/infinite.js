
let i = 0;
while (i < 5) {
  console.log(i);
}
// There is no increment so therefore it just runs forever

while (true){

}

let x = 0;
do {
 //x++;
} while (x < 5);

for (let i = 0; i > 0; i++);