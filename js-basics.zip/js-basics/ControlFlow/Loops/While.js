// While loop: the variable is not stored within the loop

//for loop example
for (let i = 1; i <= 5; i++) { 
  if (i % 2 !== 0) console.log(i); 
  }


let i = 0;
while (i <= 5) {
  if (i % 2 !== 0) console.log(i); 
  i++;
}