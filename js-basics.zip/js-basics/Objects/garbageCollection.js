
// memory is already allocated to objects when created
// we do not have to deallocate memory

//! Garbage collector job is to find variables, const that are no longer used and deallocate memory so we don't have to worry about it


