// string is primitive type, they don't have properties and methods

//string primitive

const message = 'hi';

//when we use a . notation js automatically wraps that with a object


//sting object
//(construcotr fucntion)

const another = new string('hi');



const message1 = 'this is my first message';
// message1.length imn the console returns the number of characters of the string
// can be used to set a min of max number of characters
// message1[3] (return character based on order)

//message1.includes('my')
// see if the string includes a phrase or characters


//message1.startsWith('This') 
// see if the string starts with (case sensitive)

//message1.endsWith('e')
// see if the string ends with (case sensitive)

//message1.indexOf('my') 
// shows what index of the message it is 

//message1.replace('first', 'second')
//returns only in console not in the actual code

//message1.toUppercase()

//message1.toLowerCase()

//message1.trim()
// gets rid of all of the white space before and after the message
//message1.trimLeft()
//message1.trimRight()

//message1.split(' ') means that string is split by word into an array

const message2 = 'this is my first message';

// \' means that a quote mark is in the string

// \n means new line

