


//Object literals = {}
//Boolean literals = true/ false
//String literals = '', ""
// Template literals = ` 

const another = 
`Hi John,


Thanks for reading this email

Thanks, 
Ollie`;

// template literals allow for line breaks far easier

//with template literals we can add strings dynamically

const name = 'John';

const another1 = 
`Hi ${name},


Thanks for reading this email

Thanks, 
Ollie`;

// ${} means it is a placeholder for any expression or variable or function etc.