
// Build in Object

// Math. 

//Use developer.mozilla.org and search math. javascript

// use Math when needing to do mathematical equations





//! Math.random()

// Generate random number

//example
function getRandomArbitrary(min, max) {
  return Math.random() * (max - min) + min;
}


//! Math.round()

// Rounds number up or down


//! Math.Max()

// Shows the max value out of a set of values

//! Math.Min()

// Shows the min value out of a set of values