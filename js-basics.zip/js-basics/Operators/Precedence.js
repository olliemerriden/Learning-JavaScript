//! Operator Precedence

let x1 = 2 + 3 * 4 // = 14
console.log(x1);

//USE BIDMAS to figure out which operator has priority 

//USE () to give priority to expressions 

let x2 = (2 + 3) * 4 // = 20
console.log(x2);

