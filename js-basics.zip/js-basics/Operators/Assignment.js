//! Assignment

//assign a value to a variable

//put the:  variable (e.g. +, -, *, /)= number

let a = 10;

a = a + 5;
a += 5; // this is the better way of writing the line above


a = a * 3;
a *= 3;