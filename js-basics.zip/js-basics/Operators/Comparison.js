//! Comparison

//compare the value of a variable

let b = 1;


//relational operators

console.log(b>0); //= true

//result of a comparison operator is a boolean (true or false)

console.log(b>=0); //true
console.log(b<0); //false
console.log(b<=0); //false

//equality operators
console.log(b === 1); // b is 1 
console.log(b !== 1); // b is not equal to 1

