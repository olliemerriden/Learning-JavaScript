//!Primitive Types

// two category of types: primitives/ value types, reference types


// primitives/ value types
let name2 = 'Mosh' //string literal (fancy name for string)
let age = '30'//number literal
let isApproved = true //Boolean literal: use where you need a true and false outcome
let firstName1 = undefined;
let selectedColor = null; //clear the value of the variable