//!Arrays

//square brackets mean whats in the array
let selectedColor2 = ['red', 'blue'];//each value has a index starting at 0
selectedColor2 [2] = '1'; //insert value for the index 2
console.log(selectedColor2); //console.log(selectedColor2[0]); to retrieve specific values within array

console.log(selectedColor2.length); //length is the number of items in the array