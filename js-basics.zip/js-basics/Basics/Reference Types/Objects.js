//!Objects 

//puts it within an object to make it easier (like a div)
let person = {
  name4: 'Mosh',
  age2: 30

};

//Dot notation (use this one)
person.name4 = 'John';

//Bracket notation
//?let selection = 'name4';
//?person[selection] = 'Mary';


console.log(person.name4);