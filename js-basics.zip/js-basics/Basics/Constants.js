//!Constants

//const means that the value of the variable cannot change

//?const interestRate2 = 0.3;
interestRate2 = 1; //even though i changed it because it is a constant it cannot change the value
console.log(interestRate2);
