//!Dynamic Typing

//looked at the typeof variable in the chrome console
//type of a variable can change
let name3 = 'Mosh' 
let age1 = '30'
let isApproved1 = true 
let firstName2 = undefined;
let selectedColor1 = null; 