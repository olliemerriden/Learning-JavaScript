//!Variables

let name1 = 'Mosh';
console.log(name);

//variable cannot be a reserved key word e.g. 'let'
//should be meaningful
//cannot start with a number (1name)
//not space or hyphen (-)
//case sensitive

let firstName ='Josh';
let lastName ='Park'
console.log(firstName, lastName);

let interestRate = 0.3;
interestRate = 1;
console.log(interestRate);
